<div class="carousel_ropa slide" data-ride="carousel_ropa" id="postsCarousel">    
    <div class="container p-t-0 m-t-2 carousel-inner">
            <div class="row row-equal carousel-item active m-t-0">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-img-top card-img-top-250">
                             <center><img class="card-img-top" src="<?php echo base_url().'public/images/prod-1.jpg'?>"" alt="Card image cap"></center>
                        </div>
                        <div class="card-block p-t-2">
                            <h2>
                                <center><a href='<?php echo base_url();?>tienda/tienda' class="btn btn-verde">Ropas</a></center>
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-img-top card-img-top-250">
                           <center><img class="card-img-top" src="<?php echo base_url().'public/images/prod-1.jpg'?>"" alt="Card image cap"></center>
                        </div>
                        <div class="card-block p-t-2">
                            <h2>
                                <center><a href='<?php echo base_url();?>tienda/tienda' class="btn btn-verde">Abrigos</a></center>
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-img-top card-img-top-250">
                            <center><img class="img-fluid" src="http://i.imgur.com/g27lAMl.png" alt="Carousel 3"></center>
                        </div>
                        <div class="card-block p-t-2">
                            <h2>
                                <center><a href='<?php echo base_url();?>tienda/tienda' class="btn btn-verde">Zandalias</a></center>
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row row-equal carousel-item m-t-0">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-img-top card-img-top-250">
                            <img class="img-fluid" src="//visualhunt.com/photos/l/1/office-student-work-study.jpg" alt="Carousel 4">
                        </div>
                        <div class="card-block p-t-2">
                            <h2>
                                <center><a href='<?php echo base_url();?>tienda/tienda' class="btn btn-verde">Shorts</a></center>
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-img-top card-img-top-250">
                            <img class="img-fluid" src="//visualhunt.com/photos/l/1/working-woman-technology-computer.jpg" alt="Carousel 5">
                        </div>
                        <div class="card-block p-t-2">
                            <h2>
                                <center><a href='<?php echo base_url();?>tienda/tienda' class="btn btn-verde">Camisas</a></center>
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 fadeIn wow">
                    <div class="card">
                        <div class="card-img-top card-img-top-250">
                            <img class="img-fluid" src="//visualhunt.com/photos/l/1/people-office-team-collaboration.jpg" alt="Carousel 6">
                        </div>
                        <div class="card-block p-t-2">
                            <h2>
                                <center><a href='<?php echo base_url();?>tienda/tienda' class="btn btn-verde">Franelas</a></center>
                            </h2>
                        </div>
                    </div>
                </div>
            </div>

                <a class="carousel-control-prev prev" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" role="button" data-slide="next">
                    <span class="carousel-control-next-icon next" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
    </div>
</div>