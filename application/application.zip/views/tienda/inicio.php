<!--SLIDER DE ARRIBA-->
<div class="row clases_slider">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div id="slider_ropa" class="carousel slide" data-ride="carousel">
				  <div class="carousel-inner">
						    <div class="carousel-item active">
						      <img class="d-block w-100" src="<?php echo base_url().'public/images/imagen1_tienda.jpeg'?>" alt="First slide">
						    </div>
						    <div class="carousel-item">
						      <img class="d-block w-100" src="<?php echo base_url().'public/images/imagen2_tienda.jpeg'?>" alt="Second slide">
						    </div>
						    <div class="carousel-item">
						      <img class="d-block w-100" src="<?php echo base_url().'public/images/imagen3_tienda.jpeg'?>" alt="Third slide">
						    </div>
				  </div>
				  <a class="carousel-control-prev" href="#slider_ropa" role="button" data-slide="prev">
				    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
				    <span class="sr-only">Previous</span>
				  </a>
				  <a class="carousel-control-next" href="#slider_ropa" role="button" data-slide="next">
				    <span class="carousel-control-next-icon" aria-hidden="true"></span>
				    <span class="sr-only">Next</span>
				  </a>
			</div>
	</div>
</div>
<!--SLIDER DE ARRIBA-->
<!--CARDS-->
	<?php require_once 'includes_frontend/cards.php' ?>

<!--CARDS-->


<!--MENSAJE PERSONALIZADO-->
<div class="row mensaje_clasess">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<h1>El Mejor Ecommerce de Espa&ntilde;a</h1>
	</div>

</div>

<div class="row mensaje_clasess">

		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora blanditiis expedita enim officia iste, suscipit perspiciatis facere, vel placeat, deserunt nisi delectus! Est dolores enim, ex quia itaque delectus accusamus consequatur officia tempora qui aut fugiat deserunt odio illo dolorum adipisci saepe. Sunt ipsam id veniam, consectetur aliquid possimus fuga, distinctio quisquam optio deserunt dolorum animi, ut quod. Ut facere fugit quisquam velit voluptas praesentium neque earum officiis, est laboriosam dolore quo culpa veniam voluptates deleniti quidem soluta, aliquid qui dolores, quasi asperiores molestiae a nesciunt! Accusantium quaerat nemo eaque, obcaecati quia necessitatibus, placeat aliquid perferendis perspiciatis, magnam unde sit tempora eos laboriosam voluptate. Ad rerum hic molestiae dolores, quo nihil vitae provident deserunt earum architecto atque. Saepe, ipsum architecto minima debitis ipsa voluptas eos earum aliquam. Consequuntur repudiandae atque doloremque harum quod, autem fugiat minus quam laborum corporis saepe, in obcaecati vel. Nihil amet ullam vitae reprehenderit id odit dolor nulla ut? Et, omnis, at sed deserunt voluptas praesentium quis nobis expedita minus odio nihil! Repellat velit placeat vero, at repudiandae neque! Ex minima facere provident laudantium earum sed porro qui quas neque recusandae laborum minus veritatis asperiores aliquam ab, maxime harum modi voluptas reiciendis corporis rerum? Nobis, sunt.</p>
	</div>

</div>
<!--MENSAJE PERSONALIZADO-->


<!--MENSAJE PERSONALIZADO-->
<div class="row redes_sociales">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<h1>Encuentranos!!!</h1>
	</div>

</div>

<div class="row redes_sociales" style="margin-left: 39%">

					<div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 links_redes_sociales">
						<a href=""><i class="fab fa-twitter twitter"></i></a>

					</div>

					<div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 links_redes_sociales">
						<a href=""><i class="fab fa-facebook facebook"></i></a>
					</div>

					<div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 links_redes_sociales">
						<a href=""><i class="fab fa-google-plus-g google"></i></a>
					</div>

					<div class="col-lg-1 col-md-1 col-sm-12 col-xs-12 links_redes_sociales">
						<a href=""><i class="fab fa-instagram instagram"></i></a>
					</div>

</div>
<!--MENSAJE PERSONALIZADO-->
