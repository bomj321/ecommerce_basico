	<div class="row" style="margin-top: 100px;">
		<div class="col-lg-6 offset-lg-3 col-md-6 offset-md-3 col-sm-12 col-xs-12 seccion_pago_realizado" id="captura_pantalla">
			<div class="jumbotron">
				  <p><span class="badge badge-danger">El Pago ya fue Realizado.</span></p>				  
					<p>Disculpenos su pago ya fue realizado, si cree que fue algun error contactenos. Muchas Gracias...</p>
			</div>	
		</div>
	</div>







