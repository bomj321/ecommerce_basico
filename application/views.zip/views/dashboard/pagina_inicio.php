<div class="right_col" role="main">
	   <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Datos Generales<!--<small>Todos los clientes</small>--></h3>
              </div>
            </div>
            <div class="clearfix"></div>

            <div class="row">

              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
<!--CONTENIDO-->

                  <div class="x_content">

                    <div class="row">

                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                   <center> <h1>Bienvenido al Sistema Interno del Ecommerce</h1></center>
                                </div>
                    </div>

										<div class="row pagina_inicio">
												<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
													<button class="btn btn-primary btn-block"><?php echo $total_ropa ?> Prendas</button>
												</div>

												<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
													<button class="btn btn-success btn-block"><?php echo $total_usuarios ?> Usuarios</button>

												</div>

												<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
													<button class="btn btn-warning btn-block"><?php echo $total_pagos ?> Compras</button>

												</div>

												<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
													<button class="btn btn-danger btn-block">Total: <?php echo $monto_pagos->total_compra ?> Euros</button>

												</div>
										</div>

                </div>
<!--CONTENIDO-->

              </div>
             </div>
            </div>
          </div>
</div>
        <!---------
