<div class="row footer_clasess">
        <div class="col-md-12">
            <!-- Footer -->
                  <footer class="page-footer font-small special-color-dark pt-4">                     

                              <!-- Copyright -->
                              <div class="footer-copyright text-center py-3">© 2018 Copyright:
                                <a href="www.londoneye.es">LondonEye</a>
                              </div>
                              <!-- Copyright -->

                    </footer>
           <!-- Footer -->
        </div>
</div>